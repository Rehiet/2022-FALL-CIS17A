/* 
 * File:   main.cpp
 * Author: Joel Gomez
 * Created on August 30, 2022, 11:47 AM
 * Purpose:  Hello World
 */

//System Libraries
#include <iostream> //Input/Output Library
using namespace std;

//Execution of Code Begins Here
int main(int argc, char** argv) {
    
    //Display Output
    cout<<"Hello World"<<endl;

return 0;
}

